package com.jntu.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jntu.beans.Number_of_colleges;

public interface Number_of_colleges_repo extends JpaRepository<Number_of_colleges, String> {

}
