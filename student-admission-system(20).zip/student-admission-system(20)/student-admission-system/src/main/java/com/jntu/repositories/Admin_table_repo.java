package com.jntu.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jntu.beans.Admin_table;

public interface Admin_table_repo extends JpaRepository<Admin_table, String> {

}
