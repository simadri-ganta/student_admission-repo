package com.example.demo.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.MyrestUrl;

@Controller
public class Add_college_control {
	@Autowired
	MyrestUrl resturl;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "AddCollege_req")
	public ModelAndView home1(String name, String code, String rank) {
		RestTemplate temple = new RestTemplate();
		String url = resturl.geturl()+"adcollege/";
		System.out.println(url);
		ArrayList<String> list = new ArrayList<>();
		list.add(name);
		list.add(code);
		list.add(rank);
		ArrayList<String> status = temple.postForObject(url, list, ArrayList.class);
		System.out.println(status.get(0));
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Main_admin/addCollege");
		return mv;

	}
}
