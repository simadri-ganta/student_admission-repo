package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.MyrestUrl;
import com.example.demo.entity_bean_classes.Selected_students;

@Controller
public class Login_control {
	@Autowired
	MyrestUrl resturl;

	@SuppressWarnings({ "unchecked" })
	@RequestMapping("login_admin_home")
	public ModelAndView home1(String name, String pass, HttpSession session) {
		System.out.println("myusrl is " + resturl.geturl());
		ModelAndView mv = new ModelAndView();
		if (name.equals(null) || pass.equals(null)) {
			mv.addObject("status", "please_values");
			mv.setViewName("index");
			return mv;
		} else {
			RestTemplate temple = new RestTemplate();
			String url = resturl.geturl() + "login/";
			System.out.println(url);
			ArrayList<String> list = new ArrayList<>();
			list.add(name);
			list.add(pass);
			ArrayList<String> status = temple.postForObject(url, list, ArrayList.class);
			if (!status.isEmpty()) {
				switch (status.get(0)) {
				case "valid":
					System.out.println("validdf");
					System.out.println(status.toString());
					if (status.get(1).equals("admin")) {
						mv.setViewName("Main_admin/admin_left");
						return mv;
					} else {
						mv.setViewName("college_admin/admin");
						session.setAttribute("code", status.get(1));
						session.setAttribute("registered", status.get(2));
						session.setAttribute("selected", status.get(3));
						return mv;
					}
				case "invaldi":
					mv.addObject("status", "something_went_wrong");
					mv.setViewName("index");
					return mv;
				case "no_user":
					mv.addObject("status", "null");
					mv.setViewName("index");
					return mv;
				default:
					mv.addObject("status", "wrong_pass");
					mv.setViewName("index");
					return mv;
				}
			} else {
				mv.addObject("status", "please_values");
				mv.setViewName("index");
				return mv;
			}
		}
	}

	@SuppressWarnings({ "unchecked" })
	@RequestMapping("departmentwise")
	public ModelAndView home3(HttpSession session) {
		RestTemplate temple = new RestTemplate();
		String url = resturl.geturl() + "departmentwise_request/" + session.getAttribute("code");
		ArrayList<List<Selected_students>> status = temple.getForObject(url, ArrayList.class);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("college_admin/departmentwise");
		mv.addObject("values", status);
		return mv;
	}

	@SuppressWarnings({ "unchecked" })
	@RequestMapping("status_check")
	public ModelAndView home4(String name, String password, HttpSession session) {
		ModelAndView mv = new ModelAndView("application_status");
		try {
			ArrayList<String> details = new ArrayList<>();
			details.add(name);
			String[] values = password.split("/", 4);
			System.out.println(values[0] + values[1] + values[2] + values[3]);
			details.add(values[0]);
			details.add(values[1]);
			details.add(values[3]);
			RestTemplate restcall = new RestTemplate();
			String url = resturl.geturl() + "Status_check/";
			ArrayList<String> status = restcall.postForObject(url, details, ArrayList.class);
			System.out.println(status);

			switch (status.get(0)) {
			case "user_invalid":
				System.out.println("invalid");
				mv.addObject("status", "invalid_user");
				return mv;
			case "pass_wrong":
				System.out.println("wrong");
				mv.addObject("status", "wrong_pass");
				return mv;
			case "accepted":
				System.out.println("aceeopted");
				mv.addObject("status", "accepted");
				return mv;
			case "pending":
				System.out.println("pendoinh");
				mv.addObject("status", "pending");
				return mv;
			case "rejected":
				System.out.println("reject");
				mv.addObject("status", "rejected");
				mv.addObject("choice2", status.get(1));
				mv.addObject("name", name);
				return mv;
			default:
				return mv;
			}
		} catch (Exception e) {
			mv.addObject("status", "wrong_fromat");
			return mv;
		}

	}
}
