package com.example.demo.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity_bean_classes.Admin_table;

public interface Admin_table_repo extends JpaRepository<Admin_table, String> {

}
