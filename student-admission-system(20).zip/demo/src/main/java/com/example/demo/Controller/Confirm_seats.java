package com.example.demo.Controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.MyrestUrl;

@Controller
public class Confirm_seats {
	@Autowired
	MyrestUrl resturl;

	@SuppressWarnings("unchecked")
	@RequestMapping("Confirm_allotement")
	public ModelAndView home(HttpSession session) {
		RestTemplate restcall = new RestTemplate();
		@SuppressWarnings("unused")
		ArrayList<Integer> responsecount=restcall.getForObject(resturl.geturl() + "Confirm_allotement_rest/" + session.getAttribute("code"),
				ArrayList.class);
		ModelAndView mv=new ModelAndView("college_admin/confirmationpage");
		mv.addObject("count",responsecount.toString());
		return mv;
	}
}