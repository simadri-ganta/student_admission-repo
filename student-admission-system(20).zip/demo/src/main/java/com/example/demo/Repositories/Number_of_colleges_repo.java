package com.example.demo.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity_bean_classes.Number_of_colleges;

public interface Number_of_colleges_repo extends JpaRepository<Number_of_colleges, String> {

}
