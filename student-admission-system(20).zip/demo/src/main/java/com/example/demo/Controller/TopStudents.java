package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.MyrestUrl;
import com.example.demo.entity_bean_classes.Selected_students;
@Controller
public class TopStudents {
	@Autowired
	MyrestUrl resturl;

	@SuppressWarnings("unchecked")
	@RequestMapping("top10")
	public ModelAndView home1(HttpSession session) {
		RestTemplate temple = new RestTemplate();
		String url = resturl.geturl() + "top10/" + session.getAttribute("code");
		System.out.println(url);
		List<Selected_students> status = temple.getForObject(url, ArrayList.class);
		System.out.println(status.toString());

		ModelAndView mv = new ModelAndView();
		mv.addObject("details",status);
		mv.setViewName("college_admin/top10");
		return mv;

	}
}